import { useState, useEffect } from 'react';
import { MessageCircle, Users, Home, Compass, Bell, Settings, Plus, Search, LogOut, User } from 'lucide-react';

type Page = 'home' | 'messages' | 'discover' | 'profile';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [isMobile, setIsMobile] = useState(window.innerWidth < 1024);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const inviteCode = 'Ai_Designer';

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 1024);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="flex h-screen bg-slate-950 text-slate-50 overflow-hidden">
      {/* Desktop Sidebar */}
      {!isMobile && <Sidebar currentPage={currentPage} setCurrentPage={setCurrentPage} />}

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile Header */}
        {isMobile && (
          <MobileHeader 
            currentPage={currentPage} 
            showMenu={showMobileMenu}
            setShowMenu={setShowMobileMenu}
          />
        )}

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto">
          {currentPage === 'home' && <HomePage inviteCode={inviteCode} />}
          {currentPage === 'messages' && <MessagesPage />}
          {currentPage === 'discover' && <DiscoverPage />}
          {currentPage === 'profile' && <ProfilePage inviteCode={inviteCode} />}
        </div>

        {/* Mobile Bottom Navigation */}
        {isMobile && (
          <MobileBottomNav currentPage={currentPage} setCurrentPage={setCurrentPage} />
        )}
      </div>

      {/* Mobile Menu Overlay */}
      {isMobile && showMobileMenu && (
        <MobileMenuOverlay 
          currentPage={currentPage} 
          setCurrentPage={setCurrentPage}
          setShowMenu={setShowMobileMenu}
        />
      )}
    </div>
  );
}

// ============ DESKTOP SIDEBAR ============
function Sidebar({ currentPage, setCurrentPage }: { currentPage: Page; setCurrentPage: (page: Page) => void }) {
  return (
    <div className="hidden lg:flex flex-col w-72 bg-slate-900 border-l border-slate-800 overflow-y-auto">
      {/* Logo */}
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold text-lg">
            M
          </div>
          <div>
            <h1 className="font-bold text-lg">محفل</h1>
            <p className="text-xs text-slate-400">دانشجویی، خصوصی</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        <NavItem 
          icon={<Home size={20} />} 
          label="خانه" 
          active={currentPage === 'home'}
          onClick={() => setCurrentPage('home')}
        />
        <NavItem 
          icon={<MessageCircle size={20} />} 
          label="پیام‌ها" 
          active={currentPage === 'messages'}
          onClick={() => setCurrentPage('messages')}
          badge={3}
        />
        <NavItem 
          icon={<Compass size={20} />} 
          label="کاوش" 
          active={currentPage === 'discover'}
          onClick={() => setCurrentPage('discover')}
        />
        <NavItem 
          icon={<Users size={20} />} 
          label="دوستان" 
          active={false}
          onClick={() => {}}
        />
        <NavItem 
          icon={<Bell size={20} />} 
          label="اطلاعات" 
          active={false}
          onClick={() => {}}
          badge={2}
        />
      </nav>

      {/* User Section */}
      <div className="p-4 border-t border-slate-800 space-y-2">
        <NavItem 
          icon={<User size={20} />} 
          label="پروفایل" 
          active={currentPage === 'profile'}
          onClick={() => setCurrentPage('profile')}
        />
        <NavItem 
          icon={<Settings size={20} />} 
          label="تنظیمات" 
          active={false}
          onClick={() => {}}
        />
        <NavItem 
          icon={<LogOut size={20} />} 
          label="خروج" 
          active={false}
          onClick={() => alert('خروج از حساب')}
        />
      </div>
    </div>
  );
}

// ============ NAVIGATION ITEM ============
function NavItem({ 
  icon, 
  label, 
  active, 
  onClick,
  badge 
}: { 
  icon: React.ReactNode; 
  label: string; 
  active: boolean;
  onClick: () => void;
  badge?: number;
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
        active 
          ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white' 
          : 'hover:bg-slate-800 text-slate-300'
      }`}
    >
      {icon}
      <span className="font-medium">{label}</span>
      {badge && (
        <span className="mr-auto bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
          {badge}
        </span>
      )}
    </button>
  );
}

// ============ MOBILE HEADER ============
function MobileHeader({ 
  currentPage, 
  showMenu,
  setShowMenu 
}: { 
  currentPage: Page;
  showMenu: boolean;
  setShowMenu: (show: boolean) => void;
}) {
  const titles = {
    home: 'خانه',
    messages: 'پیام‌ها',
    discover: 'کاوش',
    profile: 'پروفایل'
  };

  return (
    <div className="bg-slate-900 border-b border-slate-800 p-4 flex items-center justify-between sticky top-0 z-40">
      <button
        onClick={() => setShowMenu(!showMenu)}
        className="text-slate-300 hover:text-white"
      >
        <div className="space-y-1">
          <div className={`w-6 h-0.5 bg-current transition-all ${showMenu ? 'rotate-45 translate-y-1.5' : ''}`} />
          <div className={`w-6 h-0.5 bg-current ${showMenu ? 'opacity-0' : ''}`} />
          <div className={`w-6 h-0.5 bg-current transition-all ${showMenu ? '-rotate-45 -translate-y-1.5' : ''}`} />
        </div>
      </button>
      <h1 className="text-lg font-bold">{titles[currentPage]}</h1>
      <div className="w-6" /> {/* Spacer */}
    </div>
  );
}

// ============ MOBILE MENU OVERLAY ============
function MobileMenuOverlay({
  currentPage,
  setCurrentPage,
  setShowMenu
}: {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  setShowMenu: (show: boolean) => void;
}) {
  return (
    <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setShowMenu(false)}>
      <div className="w-64 h-full bg-slate-900 border-l border-slate-800 p-4 space-y-2 overflow-y-auto">
        <NavItem 
          icon={<Home size={20} />} 
          label="خانه" 
          active={currentPage === 'home'}
          onClick={() => { setCurrentPage('home'); setShowMenu(false); }}
        />
        <NavItem 
          icon={<MessageCircle size={20} />} 
          label="پیام‌ها" 
          active={currentPage === 'messages'}
          onClick={() => { setCurrentPage('messages'); setShowMenu(false); }}
          badge={3}
        />
        <NavItem 
          icon={<Compass size={20} />} 
          label="کاوش" 
          active={currentPage === 'discover'}
          onClick={() => { setCurrentPage('discover'); setShowMenu(false); }}
        />
        <NavItem 
          icon={<User size={20} />} 
          label="پروفایل" 
          active={currentPage === 'profile'}
          onClick={() => { setCurrentPage('profile'); setShowMenu(false); }}
        />
        <NavItem 
          icon={<Settings size={20} />} 
          label="تنظیمات" 
          active={false}
          onClick={() => setShowMenu(false)}
        />
      </div>
    </div>
  );
}

// ============ MOBILE BOTTOM NAVIGATION ============
function MobileBottomNav({ 
  currentPage, 
  setCurrentPage 
}: { 
  currentPage: Page; 
  setCurrentPage: (page: Page) => void;
}) {
  return (
    <div className="lg:hidden bg-slate-900 border-t border-slate-800 flex justify-around py-3">
      <MobileNavButton
        icon={<Home size={24} />}
        active={currentPage === 'home'}
        onClick={() => setCurrentPage('home')}
      />
      <MobileNavButton
        icon={<MessageCircle size={24} />}
        active={currentPage === 'messages'}
        onClick={() => setCurrentPage('messages')}
        badge={3}
      />
      <MobileNavButton
        icon={<Compass size={24} />}
        active={currentPage === 'discover'}
        onClick={() => setCurrentPage('discover')}
      />
      <MobileNavButton
        icon={<User size={24} />}
        active={currentPage === 'profile'}
        onClick={() => setCurrentPage('profile')}
      />
    </div>
  );
}

function MobileNavButton({
  icon,
  active,
  onClick,
  badge
}: {
  icon: React.ReactNode;
  active: boolean;
  onClick: () => void;
  badge?: number;
}) {
  return (
    <button
      onClick={onClick}
      className={`relative p-2 rounded-lg transition-colors ${
        active 
          ? 'text-purple-500' 
          : 'text-slate-400 hover:text-slate-300'
      }`}
    >
      {icon}
      {badge && (
        <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
          {badge}
        </span>
      )}
    </button>
  );
}

// ============ HOME PAGE ============
function HomePage({ inviteCode }: { inviteCode: string }) {
  return (
    <div className="max-w-4xl mx-auto p-4 lg:p-6 space-y-6">
      {/* Stories */}
      <div className="flex gap-3 overflow-x-auto pb-2 lg:hidden">
        {[1, 2, 3, 4, 5].map(i => (
          <div key={i} className="flex flex-col items-center gap-2 flex-shrink-0">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 p-0.5">
              <div className="w-full h-full rounded-full bg-slate-900" />
            </div>
            <span className="text-xs text-slate-400">کاربر {i}</span>
          </div>
        ))}
      </div>

      {/* Create Post */}
      <div className="bg-slate-900 rounded-2xl p-4 lg:p-6 border border-slate-800">
        <div className="flex gap-3 lg:gap-4 items-start">
          <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex-shrink-0" />
          <div className="flex-1">
            <input
              type="text"
              placeholder="چه خبر؟"
              className="w-full bg-slate-800 text-slate-50 rounded-full px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 placeholder-slate-500"
            />
          </div>
          <button className="bg-gradient-to-r from-purple-600 to-pink-600 p-2.5 lg:p-3 rounded-full text-white hover:from-purple-700 hover:to-pink-700 transition-all">
            <Plus size={20} />
          </button>
        </div>
      </div>

      {/* Posts */}
      {[1, 2, 3].map(i => (
        <Post key={i} inviteCode={inviteCode} postNumber={i} />
      ))}
    </div>
  );
}

// ============ POST COMPONENT ============
function Post({ inviteCode, postNumber }: { inviteCode: string; postNumber: number }) {
  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
      {/* Post Header */}
      <div className="p-4 lg:p-6 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500" />
          <div>
            <p className="font-semibold text-sm lg:text-base">کاربر شماره {postNumber}</p>
            <p className="text-xs text-slate-400">۲ ساعت پیش</p>
          </div>
        </div>
        <button className="text-slate-400 hover:text-white">⋯</button>
      </div>

      {/* Post Content */}
      <div className="p-4 lg:p-6 bg-gradient-to-br from-slate-800 to-slate-900">
        <p className="text-sm lg:text-base text-slate-200 leading-relaxed mb-4">
          این یک پست نمونه است! محفل فضایی برای اشتراک کردن افکار و ایده‌های شما است. 
          فقط با دعوت می‌توانید به این جامعه خصوصی دانشجویی بپیوندید.
        </p>
        <div className="w-full h-48 lg:h-64 rounded-xl bg-slate-700 flex items-center justify-center text-slate-400">
          تصویر
        </div>
      </div>

      {/* Post Actions */}
      <div className="p-4 lg:p-6 border-t border-slate-800 flex gap-4 text-slate-400 text-sm">
        <button className="flex items-center gap-2 hover:text-pink-500 transition-colors">
          <MessageCircle size={18} />
          <span className="hidden sm:inline">۲۳</span>
        </button>
        <button className="flex items-center gap-2 hover:text-purple-500 transition-colors">
          <Users size={18} />
          <span className="hidden sm:inline">۱۲۰</span>
        </button>
        <button className="flex items-center gap-2 hover:text-red-500 transition-colors ml-auto">
          <span className="text-lg">♥</span>
          <span className="hidden sm:inline">۴۵۶</span>
        </button>
      </div>
    </div>
  );
}

// ============ MESSAGES PAGE ============
function MessagesPage() {
  return (
    <div className="h-full flex flex-col lg:flex-row gap-0 lg:gap-6 p-0 lg:p-6 max-w-7xl mx-auto w-full">
      {/* Contacts List */}
      <div className="hidden lg:flex flex-col w-80 bg-slate-900 rounded-2xl border border-slate-800 flex-shrink-0">
        <div className="p-6 border-b border-slate-800">
          <h2 className="text-xl font-bold mb-4">پیام‌ها</h2>
          <div className="relative">
            <Search size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="جستجو..."
              className="w-full bg-slate-800 text-slate-50 rounded-full px-4 py-2.5 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 placeholder-slate-500"
            />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {[1, 2, 3, 4, 5].map(i => (
            <MessageContact key={i} name={`کاربر ${i}`} lastMessage="سلام، چطور می‌تونم کمکت کنم؟" />
          ))}
        </div>
      </div>

      {/* Chat */}
      <div className="flex-1 bg-slate-900 rounded-2xl border border-slate-800 lg:min-h-96 flex flex-col">
        <div className="p-4 lg:p-6 border-b border-slate-800 flex items-center justify-between">
          <h3 className="font-semibold">کاربر ۱</h3>
          <button className="text-slate-400 hover:text-white">⋯</button>
        </div>
        <div className="flex-1 p-4 lg:p-6 space-y-4 overflow-y-auto flex flex-col justify-end">
          <ChatMessage sender={false} text="سلام! چطوری؟" />
          <ChatMessage sender={true} text="خوبم، مرسی! تو چطور؟" />
          <ChatMessage sender={false} text="خوب‌ام. می‌خواستم ببینم آیا می‌تونی کمکم کنی؟" />
          <ChatMessage sender={true} text="البته! چی‌ای مشکل؟" />
        </div>
        <div className="p-4 border-t border-slate-800 flex gap-2">
          <input
            type="text"
            placeholder="پیام..."
            className="flex-1 bg-slate-800 text-slate-50 rounded-full px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 placeholder-slate-500"
          />
          <button className="bg-gradient-to-r from-purple-600 to-pink-600 p-2.5 rounded-full text-white hover:from-purple-700 hover:to-pink-700 transition-all">
            <Plus size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}

function MessageContact({ name, lastMessage }: { name: string; lastMessage: string }) {
  return (
    <button className="w-full p-4 border-b border-slate-800 hover:bg-slate-800 transition-colors text-right">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm">{name}</p>
          <p className="text-xs text-slate-400 truncate">{lastMessage}</p>
        </div>
      </div>
    </button>
  );
}

function ChatMessage({ sender, text }: { sender: boolean; text: string }) {
  return (
    <div className={`flex ${sender ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`max-w-xs px-4 py-2.5 rounded-2xl text-sm ${
          sender
            ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
            : 'bg-slate-800 text-slate-50'
        }`}
      >
        {text}
      </div>
    </div>
  );
}

// ============ DISCOVER PAGE ============
function DiscoverPage() {
  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">کاوش</h2>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(i => (
          <div
            key={i}
            className="aspect-square bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl cursor-pointer hover:scale-105 transition-transform flex items-center justify-center text-white font-semibold"
          >
            دسته‌بندی {i}
          </div>
        ))}
      </div>
    </div>
  );
}

// ============ PROFILE PAGE ============
function ProfilePage({ inviteCode }: { inviteCode: string }) {
  return (
    <div className="p-4 lg:p-6 max-w-2xl mx-auto space-y-6">
      {/* Profile Header */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
        {/* Cover */}
        <div className="h-32 lg:h-48 bg-gradient-to-r from-purple-600 to-pink-600" />

        {/* Profile Info */}
        <div className="p-4 lg:p-6 relative">
          <div className="flex items-end gap-4 mb-4">
            <div className="w-20 h-20 lg:w-32 lg:h-32 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 border-4 border-slate-900 -mt-10" />
            <button className="ml-auto bg-gradient-to-r from-purple-600 to-pink-600 px-4 py-2 rounded-full text-white text-sm hover:from-purple-700 hover:to-pink-700 transition-all">
              ویرایش
            </button>
          </div>
          <h1 className="text-2xl font-bold">علی محمدی</h1>
          <p className="text-slate-400 mb-4">@alimohamadi</p>
          <p className="text-slate-300 mb-4">سلام! من تو محفل خوش‌آمد‌ام 🎉</p>
          <div className="flex gap-4 text-sm">
            <div>
              <p className="font-bold">۳۲۱</p>
              <p className="text-slate-400">دنبال‌کننده</p>
            </div>
            <div>
              <p className="font-bold">۱۲۳</p>
              <p className="text-slate-400">دنبال‌کردن</p>
            </div>
          </div>
        </div>
      </div>

      {/* Invite Code */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-4 lg:p-6">
        <h3 className="font-bold mb-4">کد دعوت</h3>
        <div className="flex gap-2">
          <div className="flex-1 bg-slate-800 rounded-lg px-4 py-3 text-sm font-mono text-purple-400 flex items-center">
            {inviteCode}
          </div>
          <button
            onClick={() => {
              navigator.clipboard.writeText(inviteCode);
              alert('کپی شد!');
            }}
            className="bg-gradient-to-r from-purple-600 to-pink-600 px-4 py-3 rounded-lg text-white text-sm hover:from-purple-700 hover:to-pink-700 transition-all"
          >
            کپی
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        <StatCard label="پست‌ها" value="۴۲" />
        <StatCard label="نظرات" value="۱۸۵" />
        <StatCard label="پسندیده‌ها" value="۲۴۵۷" />
      </div>

      {/* Recent Posts */}
      <div>
        <h3 className="font-bold mb-4 text-lg">پست‌های اخیر</h3>
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-slate-900 rounded-xl border border-slate-800 p-4">
              <p className="text-sm text-slate-300">پست شماره {i}</p>
              <p className="text-xs text-slate-500 mt-2">۳ روز پیش</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 text-center">
      <p className="text-2xl font-bold text-purple-500">{value}</p>
      <p className="text-xs text-slate-400">{label}</p>
    </div>
  );
}
