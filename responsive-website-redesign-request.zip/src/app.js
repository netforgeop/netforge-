/**
 * محفل - فضای خصوصی دانشجویی
 * Standalone JavaScript App (بدون نیاز به npm)
 */

// ============ STATE MANAGEMENT ============
const state = {
    currentPage: 'home',
    isMobile: window.innerWidth < 1024,
    showMobileMenu: false,
    inviteCode: 'Ai_Designer'
};

// ============ CONSTANTS ============
const PAGES = {
    HOME: 'home',
    MESSAGES: 'messages',
    DISCOVER: 'discover',
    PROFILE: 'profile'
};

const ICONS = {
    HOME: '🏠',
    MESSAGES: '💬',
    DISCOVER: '🧭',
    PROFILE: '👤',
    SETTINGS: '⚙️',
    LOGOUT: '🚪',
    MORE: '⋯',
    ADD: '➕',
    LIKE: '♥',
    SEARCH: '🔍',
    MENU: '☰'
};

// ============ EVENT LISTENERS ============
window.addEventListener('resize', () => {
    state.isMobile = window.innerWidth < 1024;
    render();
});

// ============ NAVIGATION FUNCTIONS ============
function navigateTo(page) {
    state.currentPage = page;
    if (state.isMobile) {
        state.showMobileMenu = false;
    }
    render();
}

function toggleMobileMenu() {
    state.showMobileMenu = !state.showMobileMenu;
    render();
}

// ============ DOM CREATION HELPERS ============
function createElement(tag, className = '', innerHTML = '') {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (innerHTML) element.innerHTML = innerHTML;
    return element;
}

function createButton(label, icon, onClick, isActive = false, badge = null) {
    const btn = createElement('button', 
        `w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
            isActive 
                ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white' 
                : 'hover:bg-slate-800 text-slate-300'
        }`
    );
    
    btn.innerHTML = `
        <span class="text-xl">${icon}</span>
        <span class="font-medium">${label}</span>
        ${badge ? `<span class="ml-auto bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">${badge}</span>` : ''}
    `;
    
    btn.onclick = onClick;
    return btn;
}

// ============ SIDEBAR ============
function createSidebar() {
    const sidebar = createElement('div', 'hidden lg:flex flex-col w-72 bg-slate-900 border-l border-slate-800 overflow-y-auto');

    // Logo
    const logo = createElement('div', 'p-6 border-b border-slate-800');
    logo.innerHTML = `
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold text-lg">
                M
            </div>
            <div>
                <h1 class="font-bold text-lg">محفل</h1>
                <p class="text-xs text-slate-400">دانشجویی، خصوصی</p>
            </div>
        </div>
    `;
    sidebar.appendChild(logo);

    // Navigation
    const nav = createElement('nav', 'flex-1 p-4 space-y-2');
    
    const navItems = [
        { label: 'خانه', icon: ICONS.HOME, page: PAGES.HOME },
        { label: 'پیام‌ها', icon: ICONS.MESSAGES, page: PAGES.MESSAGES, badge: 3 },
        { label: 'کاوش', icon: ICONS.DISCOVER, page: PAGES.DISCOVER },
        { label: 'دوستان', icon: '👥', page: 'friends' },
        { label: 'اطلاعات', icon: ICONS.SETTINGS, page: 'notifications', badge: 2 },
    ];

    navItems.forEach(item => {
        const btn = createButton(
            item.label,
            item.icon,
            () => navigateTo(item.page),
            state.currentPage === item.page,
            item.badge
        );
        nav.appendChild(btn);
    });

    sidebar.appendChild(nav);

    // User Section
    const userSection = createElement('div', 'p-4 border-t border-slate-800 space-y-2');
    
    const userItems = [
        { label: 'پروفایل', icon: ICONS.PROFILE, page: PAGES.PROFILE },
        { label: 'تنظیمات', icon: ICONS.SETTINGS, page: 'settings' },
        { label: 'خروج', icon: ICONS.LOGOUT, page: 'logout' },
    ];

    userItems.forEach(item => {
        const btn = createButton(
            item.label,
            item.icon,
            () => {
                if (item.page === 'logout') {
                    alert('خروج از حساب');
                } else {
                    navigateTo(item.page);
                }
            },
            state.currentPage === item.page
        );
        userSection.appendChild(btn);
    });

    sidebar.appendChild(userSection);

    return sidebar;
}

// ============ MOBILE HEADER ============
function createMobileHeader() {
    const header = createElement('div', 'bg-slate-900 border-b border-slate-800 p-4 flex items-center justify-between sticky top-0 z-40');

    const titles = {
        [PAGES.HOME]: 'خانه',
        [PAGES.MESSAGES]: 'پیام‌ها',
        [PAGES.DISCOVER]: 'کاوش',
        [PAGES.PROFILE]: 'پروفایل'
    };

    const menuBtn = createElement('button', 'text-slate-300 hover:text-white');
    menuBtn.innerHTML = `
        <div class="space-y-1">
            <div class="w-6 h-0.5 bg-current transition-all"></div>
            <div class="w-6 h-0.5 bg-current"></div>
            <div class="w-6 h-0.5 bg-current transition-all"></div>
        </div>
    `;
    menuBtn.onclick = toggleMobileMenu;

    const title = createElement('h1', 'text-lg font-bold', titles[state.currentPage] || state.currentPage);
    const spacer = createElement('div', 'w-6');

    header.appendChild(menuBtn);
    header.appendChild(title);
    header.appendChild(spacer);

    return header;
}

// ============ MOBILE BOTTOM NAVIGATION ============
function createMobileBottomNav() {
    const nav = createElement('div', 'lg:hidden bg-slate-900 border-t border-slate-800 flex justify-around py-3');

    const items = [
        { icon: ICONS.HOME, page: PAGES.HOME },
        { icon: ICONS.MESSAGES, page: PAGES.MESSAGES, badge: 3 },
        { icon: ICONS.DISCOVER, page: PAGES.DISCOVER },
        { icon: ICONS.PROFILE, page: PAGES.PROFILE },
    ];

    items.forEach(item => {
        const btn = createElement('button', 
            `relative p-2 rounded-lg transition-colors ${
                state.currentPage === item.page ? 'text-purple-500' : 'text-slate-400 hover:text-slate-300'
            }`
        );
        btn.innerHTML = `
            <div class="text-2xl">${item.icon}</div>
            ${item.badge ? `<span class="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">${item.badge}</span>` : ''}
        `;
        btn.onclick = () => navigateTo(item.page);
        nav.appendChild(btn);
    });

    return nav;
}

// ============ MOBILE MENU OVERLAY ============
function createMobileMenuOverlay() {
    const overlay = createElement('div', 'fixed inset-0 bg-black/50 z-30 lg:hidden');
    overlay.onclick = toggleMobileMenu;

    const menu = createElement('div', 'w-64 h-full bg-slate-900 border-l border-slate-800 p-4 space-y-2 overflow-y-auto');
    menu.onclick = (e) => e.stopPropagation();

    const items = [
        { label: 'خانه', icon: ICONS.HOME, page: PAGES.HOME },
        { label: 'پیام‌ها', icon: ICONS.MESSAGES, page: PAGES.MESSAGES, badge: 3 },
        { label: 'کاوش', icon: ICONS.DISCOVER, page: PAGES.DISCOVER },
        { label: 'پروفایل', icon: ICONS.PROFILE, page: PAGES.PROFILE },
        { label: 'تنظیمات', icon: ICONS.SETTINGS, page: 'settings' },
    ];

    items.forEach(item => {
        const btn = createButton(
            item.label,
            item.icon,
            () => navigateTo(item.page),
            state.currentPage === item.page,
            item.badge
        );
        menu.appendChild(btn);
    });

    overlay.appendChild(menu);
    return overlay;
}

// ============ HOME PAGE ============
function createHomePage() {
    const container = createElement('div', 'max-w-4xl mx-auto p-4 lg:p-6 space-y-6');

    // Stories (Mobile only)
    if (state.isMobile) {
        const storiesDiv = createElement('div', 'flex gap-3 overflow-x-auto pb-2 scrollbar-hide');
        for (let i = 1; i <= 5; i++) {
            const story = createElement('div', 'flex flex-col items-center gap-2 flex-shrink-0');
            story.innerHTML = `
                <div class="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 p-0.5">
                    <div class="w-full h-full rounded-full bg-slate-900"></div>
                </div>
                <span class="text-xs text-slate-400">کاربر ${i}</span>
            `;
            storiesDiv.appendChild(story);
        }
        container.appendChild(storiesDiv);
    }

    // Create Post
    const createPostDiv = createElement('div', 'bg-slate-900 rounded-2xl p-4 lg:p-6 border border-slate-800');
    createPostDiv.innerHTML = `
        <div class="flex gap-3 lg:gap-4 items-start">
            <div class="w-10 h-10 lg:w-12 lg:h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex-shrink-0"></div>
            <div class="flex-1">
                <input type="text" placeholder="چه خبر؟" class="w-full bg-slate-800 text-slate-50 rounded-full px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 placeholder-slate-500">
            </div>
            <button class="bg-gradient-to-r from-purple-600 to-pink-600 p-2.5 lg:p-3 rounded-full text-white hover:from-purple-700 hover:to-pink-700 transition-all">
                ${ICONS.ADD}
            </button>
        </div>
    `;
    container.appendChild(createPostDiv);

    // Posts
    for (let i = 1; i <= 3; i++) {
        container.appendChild(createPost(i));
    }

    return container;
}

function createPost(postNumber) {
    const post = createElement('div', 'bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden');

    // Header
    const header = createElement('div', 'p-4 lg:p-6 flex items-center justify-between border-b border-slate-800');
    header.innerHTML = `
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500"></div>
            <div>
                <p class="font-semibold text-sm lg:text-base">کاربر شماره ${postNumber}</p>
                <p class="text-xs text-slate-400">۲ ساعت پیش</p>
            </div>
        </div>
        <button class="text-slate-400 hover:text-white">${ICONS.MORE}</button>
    `;
    post.appendChild(header);

    // Content
    const content = createElement('div', 'p-4 lg:p-6 bg-gradient-to-br from-slate-800 to-slate-900');
    content.innerHTML = `
        <p class="text-sm lg:text-base text-slate-200 leading-relaxed mb-4">
            این یک پست نمونه است! محفل فضایی برای اشتراک کردن افکار و ایده‌های شما است. 
            فقط با دعوت می‌توانید به این جامعه خصوصی دانشجویی بپیوندید.
        </p>
        <div class="w-full h-48 lg:h-64 rounded-xl bg-slate-700 flex items-center justify-center text-slate-400">
            تصویر
        </div>
    `;
    post.appendChild(content);

    // Actions
    const actions = createElement('div', 'p-4 lg:p-6 border-t border-slate-800 flex gap-4 text-slate-400 text-sm');
    actions.innerHTML = `
        <button class="flex items-center gap-2 hover:text-pink-500 transition-colors">
            💬 <span class="hidden sm:inline">۲۳</span>
        </button>
        <button class="flex items-center gap-2 hover:text-purple-500 transition-colors">
            👥 <span class="hidden sm:inline">۱۲۰</span>
        </button>
        <button class="flex items-center gap-2 hover:text-red-500 transition-colors ml-auto">
            <span class="text-lg">${ICONS.LIKE}</span>
            <span class="hidden sm:inline">۴۵۶</span>
        </button>
    `;
    post.appendChild(actions);

    return post;
}

// ============ MESSAGES PAGE ============
function createMessagesPage() {
    const container = createElement('div', 'h-full flex flex-col lg:flex-row gap-0 lg:gap-6 p-0 lg:p-6 max-w-7xl mx-auto w-full');

    // Contacts List (Desktop Only)
    if (!state.isMobile) {
        const contactsList = createElement('div', 'flex flex-col w-80 bg-slate-900 rounded-2xl border border-slate-800 flex-shrink-0');
        
        const header = createElement('div', 'p-6 border-b border-slate-800');
        header.innerHTML = `
            <h2 class="text-xl font-bold mb-4">پیام‌ها</h2>
            <div class="relative">
                <span class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500">${ICONS.SEARCH}</span>
                <input type="text" placeholder="جستجو..." class="w-full bg-slate-800 text-slate-50 rounded-full px-4 py-2.5 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 placeholder-slate-500">
            </div>
        `;
        contactsList.appendChild(header);

        const contacts = createElement('div', 'flex-1 overflow-y-auto');
        for (let i = 1; i <= 5; i++) {
            const contact = createElement('button', 'w-full p-4 border-b border-slate-800 hover:bg-slate-800 transition-colors text-right');
            contact.innerHTML = `
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex-shrink-0"></div>
                    <div class="flex-1 min-w-0">
                        <p class="font-medium text-sm">کاربر ${i}</p>
                        <p class="text-xs text-slate-400 truncate">سلام، چطور می‌تونم کمکت کنم؟</p>
                    </div>
                </div>
            `;
            contacts.appendChild(contact);
        }
        contactsList.appendChild(contacts);
        container.appendChild(contactsList);
    }

    // Chat
    const chat = createElement('div', 'flex-1 bg-slate-900 rounded-2xl border border-slate-800 lg:min-h-96 flex flex-col');

    const chatHeader = createElement('div', 'p-4 lg:p-6 border-b border-slate-800 flex items-center justify-between');
    chatHeader.innerHTML = `
        <h3 class="font-semibold">کاربر ۱</h3>
        <button class="text-slate-400 hover:text-white">${ICONS.MORE}</button>
    `;
    chat.appendChild(chatHeader);

    const messages = createElement('div', 'flex-1 p-4 lg:p-6 space-y-4 overflow-y-auto flex flex-col justify-end');

    const chatMessages = [
        { sender: false, text: 'سلام! چطوری؟' },
        { sender: true, text: 'خوبم، مرسی! تو چطور؟' },
        { sender: false, text: 'خوب‌ام. می‌خواستم ببینم آیا می‌تونی کمکم کنی؟' },
        { sender: true, text: 'البته! چی‌ای مشکل؟' },
    ];

    chatMessages.forEach(msg => {
        const msgDiv = createElement('div', `flex ${msg.sender ? 'justify-end' : 'justify-start'}`);
        msgDiv.innerHTML = `
            <div class="max-w-xs px-4 py-2.5 rounded-2xl text-sm ${
                msg.sender
                    ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
                    : 'bg-slate-800 text-slate-50'
            }">
                ${msg.text}
            </div>
        `;
        messages.appendChild(msgDiv);
    });

    chat.appendChild(messages);

    const inputArea = createElement('div', 'p-4 border-t border-slate-800 flex gap-2');
    inputArea.innerHTML = `
        <input type="text" placeholder="پیام..." class="flex-1 bg-slate-800 text-slate-50 rounded-full px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 placeholder-slate-500">
        <button class="bg-gradient-to-r from-purple-600 to-pink-600 p-2.5 rounded-full text-white hover:from-purple-700 hover:to-pink-700 transition-all">
            ${ICONS.ADD}
        </button>
    `;
    chat.appendChild(inputArea);

    container.appendChild(chat);
    return container;
}

// ============ DISCOVER PAGE ============
function createDiscoverPage() {
    const container = createElement('div', 'p-4 lg:p-6 max-w-7xl mx-auto');

    const title = createElement('h2', 'text-2xl font-bold mb-6', 'کاوش');
    container.appendChild(title);

    const grid = createElement('div', 'grid grid-cols-2 lg:grid-cols-3 gap-4');

    for (let i = 1; i <= 9; i++) {
        const item = createElement('div', 'aspect-square bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl cursor-pointer hover:scale-105 transition-transform flex items-center justify-center text-white font-semibold');
        item.textContent = `دسته‌بندی ${i}`;
        grid.appendChild(item);
    }

    container.appendChild(grid);
    return container;
}

// ============ PROFILE PAGE ============
function createProfilePage() {
    const container = createElement('div', 'p-4 lg:p-6 max-w-2xl mx-auto space-y-6');

    // Profile Header
    const profile = createElement('div', 'bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden');

    const cover = createElement('div', 'h-32 lg:h-48 bg-gradient-to-r from-purple-600 to-pink-600');
    profile.appendChild(cover);

    const info = createElement('div', 'p-4 lg:p-6 relative');
    info.innerHTML = `
        <div class="flex items-end gap-4 mb-4">
            <div class="w-20 h-20 lg:w-32 lg:h-32 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 border-4 border-slate-900 -mt-10"></div>
            <button class="ml-auto bg-gradient-to-r from-purple-600 to-pink-600 px-4 py-2 rounded-full text-white text-sm hover:from-purple-700 hover:to-pink-700 transition-all">
                ویرایش
            </button>
        </div>
        <h1 class="text-2xl font-bold">علی محمدی</h1>
        <p class="text-slate-400 mb-4">@alimohamadi</p>
        <p class="text-slate-300 mb-4">سلام! من تو محفل خوش‌آمد‌ام 🎉</p>
        <div class="flex gap-4 text-sm">
            <div>
                <p class="font-bold">۳۲۱</p>
                <p class="text-slate-400">دنبال‌کننده</p>
            </div>
            <div>
                <p class="font-bold">۱۲۳</p>
                <p class="text-slate-400">دنبال‌کردن</p>
            </div>
        </div>
    `;
    profile.appendChild(info);
    container.appendChild(profile);

    // Invite Code
    const inviteDiv = createElement('div', 'bg-slate-900 rounded-2xl border border-slate-800 p-4 lg:p-6');
    inviteDiv.innerHTML = `
        <h3 class="font-bold mb-4">کد دعوت</h3>
        <div class="flex gap-2">
            <div class="flex-1 bg-slate-800 rounded-lg px-4 py-3 text-sm font-mono text-purple-400 flex items-center">
                ${state.inviteCode}
            </div>
            <button class="bg-gradient-to-r from-purple-600 to-pink-600 px-4 py-3 rounded-lg text-white text-sm hover:from-purple-700 hover:to-pink-700 transition-all">
                کپی
            </button>
        </div>
    `;
    const copyBtn = inviteDiv.querySelector('button');
    copyBtn.onclick = () => {
        navigator.clipboard.writeText(state.inviteCode);
        copyBtn.textContent = '✓ کپی شد';
        setTimeout(() => {
            copyBtn.textContent = 'کپی';
        }, 2000);
    };
    container.appendChild(inviteDiv);

    // Stats
    const stats = createElement('div', 'grid grid-cols-2 lg:grid-cols-3 gap-4');
    const statItems = [
        { label: 'پست‌ها', value: '۴۲' },
        { label: 'نظرات', value: '۱۸۵' },
        { label: 'پسندیده‌ها', value: '۲۴۵۷' },
    ];
    statItems.forEach(item => {
        const statDiv = createElement('div', 'bg-slate-900 rounded-xl border border-slate-800 p-4 text-center');
        statDiv.innerHTML = `
            <p class="text-2xl font-bold text-purple-500">${item.value}</p>
            <p class="text-xs text-slate-400">${item.label}</p>
        `;
        stats.appendChild(statDiv);
    });
    container.appendChild(stats);

    // Recent Posts
    const recent = createElement('div');
    recent.innerHTML = '<h3 class="font-bold mb-4 text-lg">پست‌های اخیر</h3>';
    const postsDiv = createElement('div', 'space-y-4');

    for (let i = 1; i <= 3; i++) {
        const post = createElement('div', 'bg-slate-900 rounded-xl border border-slate-800 p-4');
        post.innerHTML = `
            <p class="text-sm text-slate-300">پست شماره ${i}</p>
            <p class="text-xs text-slate-500 mt-2">۳ روز پیش</p>
        `;
        postsDiv.appendChild(post);
    }

    recent.appendChild(postsDiv);
    container.appendChild(recent);

    return container;
}

// ============ MAIN RENDER FUNCTION ============
function render() {
    const app = document.getElementById('app');
    if (!app) return;

    app.innerHTML = '';

    const mainDiv = createElement('div', 'flex h-screen bg-slate-950 text-slate-50 overflow-hidden');

    // Desktop Sidebar
    if (!state.isMobile) {
        mainDiv.appendChild(createSidebar());
    }

    // Main Content
    const contentDiv = createElement('div', 'flex-1 flex flex-col overflow-hidden');

    // Mobile Header
    if (state.isMobile) {
        contentDiv.appendChild(createMobileHeader());
    }

    // Content Area
    const contentArea = createElement('div', 'flex-1 overflow-y-auto');
    
    switch (state.currentPage) {
        case PAGES.HOME:
            contentArea.appendChild(createHomePage());
            break;
        case PAGES.MESSAGES:
            contentArea.appendChild(createMessagesPage());
            break;
        case PAGES.DISCOVER:
            contentArea.appendChild(createDiscoverPage());
            break;
        case PAGES.PROFILE:
            contentArea.appendChild(createProfilePage());
            break;
        default:
            contentArea.appendChild(createHomePage());
    }

    contentDiv.appendChild(contentArea);

    // Mobile Bottom Navigation
    if (state.isMobile) {
        contentDiv.appendChild(createMobileBottomNav());
    }

    mainDiv.appendChild(contentDiv);

    // Mobile Menu Overlay
    if (state.isMobile && state.showMobileMenu) {
        mainDiv.appendChild(createMobileMenuOverlay());
    }

    app.appendChild(mainDiv);
}

// ============ INITIALIZATION ============
document.addEventListener('DOMContentLoaded', () => {
    render();
});
